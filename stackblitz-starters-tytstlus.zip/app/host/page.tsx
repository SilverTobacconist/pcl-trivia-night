"use client";

import { useState } from "react";

export default function HostPage() {
  const [location, setLocation] = useState("Hastings");
  const [hostName, setHostName] = useState("John");
  const [lookupCode, setLookupCode] = useState("");
  const [session, setSession] = useState<any>(null);
  const [players, setPlayers] = useState<any[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState<any>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function createSession() {
    setLoading(true);
    setError("");
    setSession(null);
    setPlayers([]);

    const response = await fetch("/api/sessions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ location, hostName }),
    });

    const data = await response.json();
    setLoading(false);

    if (!response.ok) {
      setError(data.error || "Something went wrong");
      return;
    }

    setSession(data.session);
    setLookupCode(data.session.session_code);
  }

  async function loadSession() {
    setLoading(true);
    setError("");
    setSession(null);
    setPlayers([]);

    const response = await fetch(
      `/api/session-by-code?sessionCode=${lookupCode}`
    );

    const data = await response.json();
    setLoading(false);

    if (!response.ok) {
      setError(data.error || "Could not load session");
      return;
    }

    setSession(data.session);
  }

  async function loadPlayers() {
    if (!session?.id) return;

    const response = await fetch(`/api/players?sessionId=${session.id}`);
    const data = await response.json();

    if (!response.ok) {
      setError(data.error || "Could not load players");
      return;
    }

    setPlayers(data.players);
  }

  async function loadNextQuestion() {
    if (!session?.id) return;

    setError("");
    setCurrentQuestion(null);

    const response = await fetch("/api/next-question", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        sessionId: session.id,
        location: session.location,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      setError(
        [
          data.error,
          data.details && `Details: ${data.details}`,
          data.code && `Code: ${data.code}`,
          data.hint && `Hint: ${data.hint}`,
        ]
          .filter(Boolean)
          .join(" ")
      );
      return;
    }

    setCurrentQuestion(data.question);
  }

  return (
    <main style={{ padding: "2rem", fontFamily: "Arial, sans-serif" }}>
      <h1>PCL Trivia Night Host Dashboard</h1>

      {!session && (
        <>
          <h2>Create New Session</h2>

          <div style={{ marginBottom: "1rem" }}>
            <label>
              Location:{" "}
              <select
                value={location}
                onChange={(event) => setLocation(event.target.value)}
                style={{ padding: "0.5rem" }}
              >
                <option value="Hastings">Hastings</option>
                <option value="Norfolk">Norfolk</option>
              </select>
            </label>
          </div>

          <div style={{ marginBottom: "1rem" }}>
            <label>
              Host Name:{" "}
              <input
                value={hostName}
                onChange={(event) => setHostName(event.target.value)}
                style={{ padding: "0.5rem" }}
              />
            </label>
          </div>

          <button
            onClick={createSession}
            disabled={loading}
            style={{
              background: "#111",
              color: "white",
              padding: "0.75rem 1.25rem",
              border: "none",
              borderRadius: "6px",
              cursor: "pointer",
              fontSize: "1rem",
              marginBottom: "2rem",
            }}
          >
            {loading ? "Creating..." : "Create Session"}
          </button>

          <hr />

          <h2>Load Existing Session</h2>

          <div style={{ marginBottom: "1rem" }}>
            <label>
              Session Code:{" "}
              <input
                value={lookupCode}
                onChange={(event) => setLookupCode(event.target.value)}
                style={{ padding: "0.5rem" }}
              />
            </label>
          </div>

          <button
            onClick={loadSession}
            disabled={loading}
            style={{
              background: "#333",
              color: "white",
              padding: "0.75rem 1.25rem",
              border: "none",
              borderRadius: "6px",
              cursor: "pointer",
              fontSize: "1rem",
            }}
          >
            {loading ? "Loading..." : "Load Session"}
          </button>
        </>
      )}

      {error && (
        <div style={{ marginTop: "1rem", color: "red" }}>
          <strong>Error:</strong> {error}
        </div>
      )}

      {session && (
        <section style={{ marginTop: "2rem" }}>
          <h2>Active Session</h2>

          <p>
            <strong>Code:</strong> {session.session_code}
          </p>
          <p>
            <strong>Location:</strong> {session.location}
          </p>
          <p>
            <strong>Status:</strong> {session.status}
          </p>

          <button
            onClick={loadPlayers}
            style={{
              background: "#333",
              color: "white",
              padding: "0.6rem 1rem",
              border: "none",
              borderRadius: "6px",
              cursor: "pointer",
              marginTop: "1rem",
            }}
          >
            Refresh Players
          </button>

          <button
  onClick={loadNextQuestion}
  style={{
    background: "#111",
    color: "white",
    padding: "0.6rem 1rem",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    marginTop: "1rem",
    marginLeft: "0.5rem",
  }}
>
  Next Question
</button>

          <button
            onClick={() => {
              setSession(null);
              setPlayers([]);
            }}
            style={{
              background: "#777",
              color: "white",
              padding: "0.6rem 1rem",
              border: "none",
              borderRadius: "6px",
              cursor: "pointer",
              marginTop: "1rem",
              marginLeft: "0.5rem",
            }}
          >
            Back
          </button>

          <h3 style={{ marginTop: "2rem" }}>Players Joined</h3>

          {players.length === 0 ? (
            <p>No players loaded yet.</p>
          ) : (
            <ul>
              {players.map((player) => (
                <li key={player.id}>
                  {player.display_name} - {player.score} pts
                </li>
              ))}
            </ul>
          )}
          {currentQuestion && (
  <section
    style={{
      marginTop: "2rem",
      padding: "1rem",
      border: "1px solid #ccc",
    }}
  >
    <h3>Current Question</h3>

    <p>
      <strong>ID:</strong> {currentQuestion.question_id}
    </p>

    <p>
      <strong>Category:</strong> {currentQuestion.category}
    </p>

    <p>
      <strong>Subcategory:</strong> {currentQuestion.subcategory}
    </p>

    <p>
      <strong>Difficulty:</strong> {currentQuestion.difficulty}
    </p>

    <p>
      <strong>Question:</strong> {currentQuestion.question_text}
    </p>

    <p>
      <strong>Answer:</strong> {currentQuestion.answer}
    </p>
  </section>
)}
        </section>
      )}
    </main>
  );
}